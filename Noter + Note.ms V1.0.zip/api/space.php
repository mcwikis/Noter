<?php
$limit=1024*1024*1024;
$file_limit=512;
function init_json($dirPath)
{
    $files=glob($dirPath . '/*.txt');
    $fileSizes=[];
    foreach ($files as $file)
    {
        $size=filesize($file);
        $filename=basename($file);
        $fileSizes[$filename]=$size;
    }
    write_json('list.json',$fileSizes);
    init_size();
}
function init_size()
{
    $data=read_json('list.json');
    $sum=array_sum($data);
    write_json('size.json',['size'=>$sum]);
}
function read_json($filename)
{
    if(!file_exists($filename)){return [];}
    $content=file_get_contents($filename);
    $data=json_decode($content,true);
    if(json_last_error()!==JSON_ERROR_NONE)
    {
        http_response_code(500);
        exit('Error decoding JSON from ' . $filename);
    }
    return $data;
}
function write_json($filename, $data)
{
    file_put_contents($filename,json_encode($data,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}
$dirPath='./../notes';
if (isset($_GET['type']))
{
    $type=$_GET['type']??'';
    $filename=$_GET['name']??'';
    $filesize=isset($_GET['size'])?(int)$_GET['size']:0;
    if($filesize>$file_limit)http_response_code(400);
    if(!file_exists('list.json')){init_json($dirPath);}
    if(!file_exists('size.json')){init_size();}
    $data=read_json('list.json');
    $allsize=read_json('size.json');
    if($type==='add')
    {
        $currentSize=$data[$filename]??0;
        if($allsize['size']+$filesize-$currentSize>$limit)
        {
            http_response_code(400);
            exit('Size limit exceeded');
        }
        $allsize['size']+=$filesize-$currentSize;
        $data[$filename]=$filesize;
    }elseif($type==='delete')
    {
        $allsize['size']-=$filesize;
        unset($data[$filename]);
    }
    write_json('list.json',$data);
    write_json('size.json',$allsize);
}
?>