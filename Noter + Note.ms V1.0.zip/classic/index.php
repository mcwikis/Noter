<?php
$URL="http://noter.us.kg/classic";
$FOLDER="./../notes";
function sanitize_file_name($filename)
{
    return trim(preg_replace('/[\s-]+/','-',str_replace(
        array("?","[","]","/","\\","=","<",">",":",";",",","'","\"","&","$","#","*","(",")","|","~","`","!","{","}","."),
        '', 
        $filename
    )),'.-_');
}
if(!isset($_GET["f"]))
{
    $lines=file("words.txt");
    $name=trim($lines[array_rand($lines)],"\n");
    while(file_exists($FOLDER."/".$name) && strlen($name)<10)
    {
        $name.=rand(0,9);
    }
    if(strlen($name)<10)
    {
        header("Location: ".$URL."/".$name);
    }
    die();
}
$name=sanitize_file_name($_GET["f"]);
$path=$FOLDER."/".$name.".txt";
$content=$_POST["t"];
if(isset($content))
{
    $type=strlen($content)?'add':'delete';
    file_put_contents($path,$content);
    $ch=curl_init("http://noter.us.kg/api/space.php?type=$type&name=$name.txt");
    curl_setopt($ch,CURLOPT_POST,1);
    curl_exec($ch);
    $http_code=curl_getinfo($ch,CURLINFO_HTTP_CODE);
    curl_close($ch);
    if($http_code==200)
    {
        file_put_contents($path,$content);
    }else
    {
        echo "Error: Could not save the file. HTTP Status Code: ".$http_code;
    }
    die();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="theme-color" content="#ebeef2" />
    <title>Noter 网页记事本</title>
    <link href="styles.css" rel="stylesheet" />
    <link rel="icon" href="favicon.ico" type="image/ico" />
</head>
<body>
    <div class="stack">
        <div class="layer">
            <div class="layer">
                <div class="layer">
                <textarea class="content"><?php if (file_exists($path)) { print htmlspecialchars(file_get_contents($path)); } ?></textarea>
                </div>
            </div>
        </div>
    </div>
    <div class="flag">
        <a href="<?php print $URL; ?>/<?php print $name; ?>">Noter / <?php print $name; ?></a>
    </div>
    <pre class="print"></pre>
    <script src="jquery.min.js"></script>
    <script src="jquery.textarea.js"></script>
    <script src="script.js"></script>
</body>
</html>