$(function()
{
    var $textarea=$(".content");
    var content=$textarea.val();
    $textarea.tabby();
    $(".print").text(content);
    $textarea.focus();
    setInterval(function()
    {
        if (content!==$textarea.val())
        {
            content=$textarea.val();
            $.ajax({
                type: "POST",
                data: "&t="+encodeURIComponent(content)
            });
            $(".print").text(content);
        }
    },1000);
});
