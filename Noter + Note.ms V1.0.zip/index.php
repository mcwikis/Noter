<?php
$filename=isset($_GET['name'])?$_GET['name'].'.txt':'default.txt';
$directory=__DIR__.'/notes';
$filePath=$directory . '/' . $filename;
if($_SERVER['REQUEST_METHOD']==='POST')
{
    $content=$_POST['content'];
    file_put_contents($filePath,$content);
    $type=strlen($content)?'add':'delete';
    $ch=curl_init("http://noter.us.kg/api/space.php?type=$type&name=$filename");
    curl_setopt($ch,CURLOPT_POST,1);
    curl_exec($ch);
    curl_close($ch);
}
$content=file_exists($filePath)?file_get_contents($filePath):'';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>记事本 - <?php echo htmlspecialchars($_GET['name'] ?? 'default'); ?></title>
    <link rel="stylesheet" type="text/css" href="/css/style.css">
    <link rel="icon" href="/img/notepad.png" type="image/x-icon">
</head>
<body>
    <div class="window" id="notepad-window">
        <div class="window-header">
            <div style="display: flex; align-items: center;">
                <img src="./img/notepad.png" alt="Logo">
                <h1>记事本 - <?php echo htmlspecialchars($_GET['name'] ?? 'default'); ?></h1>
            </div>
            <div class="window-buttons">
                <button class="save" id="save-btn" title="Save"></button>
                <button class="fullscreen" id="fullscreen-btn" title="Toggle Fullscreen"></button>
                <button class="turn" id="toggle-editor-btn" title="Toggle Editor"></button>
                <button class="close" title="Close"></button>
            </div>
        </div>
        <link rel="stylesheet" href="./css/simplemde.min.css">
        <script src="./js/simplemde.min.js"></script>
        <div class="notepad-container">
            <form id="notepad-form" method="POST">
                <textarea class="textarea" name="content" id="notepad-content"><?php echo htmlspecialchars($content); ?></textarea>
            </form>
            <?php if (isset($error)): ?>
                <a class="error"><?php echo $error; ?></a>
            <?php endif; ?>
        </div>
        <script>
        var isMarkdown=true;
        var isFullscreen=false;
        const textarea=document.getElementById('notepad-content');
        const toggleEditorBtn=document.getElementById('toggle-editor-btn');
        const fullscreenBtn=document.getElementById('fullscreen-btn');
        const notepadWindow=document.getElementById('notepad-window');
        function InitMarkdown(simplemde)
        {
            simplemde=new SimpleMDE({
                element: document.getElementById("notepad-content"),
                placeholder: "输入...",
                previewRender: function(plainText)
                {
                    return markdownit().render(plainText);
                },
                spellChecker: false,
                status: false
            });
            return simplemde;
        }
        function updateEditorHeight()
        {
            if(!isMarkdown)
            {
                const height=isFullscreen?'calc(100vh - 100px)':'50vh';
                textarea.style.height=height;
                textarea.style.width='100%';
                textarea.style.resize='none';
                textarea.style.outline='none';
            }
        }
        var simplemde;
        if(isMarkdown)simplemde=InitMarkdown(simplemde);
        else simplemde=document.getElementById("notepad-content");
        toggleEditorBtn.addEventListener('click',function()
        {
            isMarkdown=!isMarkdown;
            if(!isMarkdown)
            {
                simplemde.toTextArea();
                simplemde=null;
                textarea.style.display='block';
                updateEditorHeight();
            }else
            {
                textarea.style.display='none';
                simplemde=InitMarkdown(simplemde);
            }
        });
        fullscreenBtn.addEventListener('click',function()
        {
            isFullscreen=!isFullscreen;
            if(isFullscreen)
            {
                notepadWindow.requestFullscreen().catch(err=>
                {
                    alert(`无法进行窗口全屏: ${err.message} (${err.name})`);
                });
            }else
            {
                document.exitFullscreen();
            }
            updateEditorHeight();
        });
        const saveBtn=document.getElementById('save-btn');
        saveBtn.addEventListener('click',function()
        {
            document.getElementById('notepad-form').submit();
        });
    </script>
    </div>
</body>
</html>